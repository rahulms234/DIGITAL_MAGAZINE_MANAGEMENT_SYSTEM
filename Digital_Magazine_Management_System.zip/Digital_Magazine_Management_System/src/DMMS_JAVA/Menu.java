package DMMS_JAVA;
import java.util.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.*;

public class Menu {
	private static Scanner scanner = new Scanner(System.in);

    public static void displayMainMenu() {
        while (true) {
            System.out.println("1. User Management");
            System.out.println("2. Magazine Management");
            System.out.println("3. Article Management");
            System.out.println("4. Subscription Management");
            System.out.println("5. Exit");
            System.out.print("Enter the number you need to access: ");
            int choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    displayUserMenu();
                    break;
                case 2:
                    displayMagazineMenu();
                    break;
                case 3:
                    displayArticleMenu();
                    break;
                case 4:
                    displaySubscriptionMenu();
                    break;
                case 5:
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    
    }
    
    



private static void displayUserMenu() {
    	 while (true) {
             System.out.println("\nUser Management:");
             System.out.println("1. Add User");
             System.out.println("2. View All Users");
             System.out.println("3. Update User");
             System.out.println("4. Delete User");
             System.out.println("5. Get User");
             System.out.println("6. Back to Main Menu");

             int choice = getIntInput();

             switch (choice) {
                 case 1:
                     addUser();
                     break;
                 case 2:
                     viewAllUsers();
                     break;
                 case 3:
                     updateUser();
                     break;
                 case 4:
                     deleteUser();
                     break;
                 case 5:
                     getUser();
                     break;
                 case 6:
                     return;
                 default:
                     System.out.println("Invalid choice. Please try again.");
             }
    	 }
    }
    
    
   
	private static void addUser() {
        System.out.print("Enter username: ");
        String username = scanner.next();
        System.out.print("Enter email: ");
        String email = scanner.next();
        System.out.print("Enter date of birth in this (yyyy-mm-dd) manner: ");
        String dob=scanner.next();
        Date dateOfBirth=convertDate(dob);
        System.out.print("Enter registration date in this (yyyy-mm-dd) manner: ");
        String regisDate=scanner.next();
        Date registrationDate =convertDate(regisDate);
        
        User user = new User();
        user.setUsername(username);
        user.setEmail(email);
        user.setDateOfBirth(dateOfBirth);
        user.setRegistrationDate(registrationDate);       
        UserService.addUser(user);
    }
    
    
    
     private static Date convertDate(String input)
     {
    	 SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
         Date registrationDate = null;
         try {
             registrationDate = dateFormat.parse(input);
         } catch (java.text.ParseException e) 
         {
             e.printStackTrace();
         }
         return registrationDate;
     }
    
     
     
    private static void deleteUser() {
    	System.out.print("Enter userId: ");
        int userId = scanner.nextInt();
        UserService.deleteUser(userId);
		
	}

    
    
    
	private static void updateUser() {
		System.out.print("Enter userId: ");
        int userId = scanner.nextInt();
        if(!isUserIdExists(userId))
        {
        	System.out.println("Invalid Id Try Again!!");
        	return;
        }
        
		System.out.print("Enter username: ");
        String username = scanner.next();
        System.out.print("Enter email: ");
        String email = scanner.next();
        System.out.print("Enter date of birth in (yyyy-mm-dd) manner: ");
        String dob=scanner.next();
        Date dateOfBirth=convertDate(dob);
        System.out.print("Enter registration date (yyyy-mm-dd) manner: ");
        String regisDate=scanner.next();
        Date registrationDate =convertDate(regisDate);
        
        User user = new User();
        user.setUserId(userId);
        user.setUsername(username);
        user.setEmail(email);
        user.setDateOfBirth(dateOfBirth);
        user.setRegistrationDate(registrationDate);       
        UserService.updateUser(user);
		
	}

	 public static boolean isUserIdExists(int userId) {
	        String sql = "SELECT 1 FROM User WHERE user_id = ?";
	        try (Connection conn = DbConnection.getConnection();
	             PreparedStatement stmt = conn.prepareStatement(sql)) {
	            stmt.setInt(1, userId);
	            try (ResultSet rs = stmt.executeQuery()) {
	                return rs.next(); 
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return false;
	    }
	
	private static void viewAllUsers() {
		 UserService.viewAllUsers();
	}

	
	private static void getUser() {
		System.out.print("Enter userId: ");
        int userId = scanner.nextInt();
        User user = UserService.getUser(userId);
        if (user != null) {
            System.out.println("ID: " + user.getUserId() +
                               ", Username: " + user.getUsername() +
                               ", Email: " + user.getEmail() +
                               ", Date of Birth: " + user.getDateOfBirth() +
                               ", Registration Date: " + user.getRegistrationDate());
        } else {
            System.out.println("User not found.");
        }
   }
     
	 
     
private static void displayMagazineMenu() {
    	  while (true) {
              System.out.println("\nMagazine Management:");
              System.out.println("1. Add Magazine");
              System.out.println("2. View All Magazines");
              System.out.println("3. Update Magazine");
              System.out.println("4. Delete Magazine");
              System.out.println("5. Back to Main Menu");

              int choice = getIntInput();

              switch (choice) {
                  case 1:
                      addMagazine();
                      break;
                  case 2:
                      viewAllMagazines();
                      break;
                  case 3:
                      updateMagazine();
                      break;
                  case 4:
                      deleteMagazine();
                      break;
                  case 5:
                      return;
                  default:
                      System.out.println("Invalid choice. Please try again.");
              }
    	  }
    }

    private static void addMagazine() {
		
		System.out.print("Enter the magazine title: ");
		String magazineTitle=scanner.next();
		System.out.print("Enter the generation of magazine: ");
		String generation=scanner.next();
		System.out.print("Enter the publication frequency: ");
		String frequency=scanner.next();
		System.out.print("Enter the publisher: ");
		String publisher=scanner.next();
		
		Magazine magazine=new Magazine();
		magazine.setTitle(magazineTitle);
		magazine.setGenre(generation);
		magazine.setPublicationFrequency(frequency);
		magazine.setPublisher(publisher);
		
		MagazineService.addMagazine(magazine);
		
		
	}

	private static void viewAllMagazines() {
		
		MagazineService.viewAllMagazines();
		
	}
	
	
	
	private static void updateMagazine() {
		
		System.out.print("Enter magazineId: ");
        int magazineId = scanner.nextInt();
        if(!isMagazineIdExists(magazineId))
        {
        	System.out.println("Invalid ID Try Again!");
        	return;
        }
		System.out.print("Enter title: ");
        String magazineTitle = scanner.next();
        System.out.print("Enter generation: ");
        String generation = scanner.next();
        System.out.print("Enter publication frequency: ");
        String frequency=scanner.next();
        System.out.print("Enter publisher: ");
        String publisher=scanner.next();
        
        
        Magazine magazine = new Magazine();
        magazine.setMagazineId(magazineId);
        magazine.setTitle(magazineTitle);
        magazine.setGenre(generation);
        magazine.setPublicationFrequency(frequency);
        magazine.setPublisher(publisher);   
        
        MagazineService.updateMagazine(magazine);
		
		
		
		
	}
	
	
	 public static boolean isMagazineIdExists(int magazineId) {
	        String sql = "SELECT 1 FROM Magazine WHERE magazine_id = ?";
	        try (Connection conn = DbConnection.getConnection();
	             PreparedStatement stmt = conn.prepareStatement(sql)) {
	            stmt.setInt(1, magazineId);
	            try (ResultSet rs = stmt.executeQuery()) {
	                return rs.next(); 
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return false;
	    }
	

	private static void deleteMagazine() {
		
		System.out.print("Enter magazineId: ");
		int magazine_Id=scanner.nextInt();
		MagazineService.deleteMagazine(magazine_Id);
		
	}



private static void displayArticleMenu() {
    	while (true) {
            System.out.println("\nArticle Management:");
            System.out.println("1. Add Article");
            System.out.println("2. View All Articles");
            System.out.println("3. Update Article");
            System.out.println("4. Delete Article");
            System.out.println("5. Back to Main Menu");

            int choice = getIntInput();

            switch (choice) {
                case 1:
                    addArticle();
                    break;
                case 2:
                    viewAllArticles();
                    break;
                case 3:
                    updateArticle();
                    break;
                case 4:
                    deleteArticle();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void addArticle() {
		
    	System.out.print("Enter magazineId: ");
    	int magazineId=scanner.nextInt();
    	System.out.print("Enter the title: ");
    	String magazineTitle=scanner.next();
    	System.out.print("Enter the name of the author: ");
    	String author=scanner.next();
    	System.out.print("Enter the content: ");
    	String content=scanner.next();
    	System.out.print("Enter publish date (yyyy-mm-dd) manner: ");
        String publiDate=scanner.next();
        Date publishDate =convertDate(publiDate);
        
        Article article=new Article();
        article.setMagazineId(magazineId);
        article.setTitle(magazineTitle);
        article.setAuthor(author);
        article.setContent(content);
        article.setPublishDate(publishDate);
        
        ArticleService.addArticle(article);
        
    	
		
	}

	private static void viewAllArticles() {
		
		ArticleService.viewAllArticles();
		
	}

	private static void updateArticle() {
		
		
		System.out.print("Enter articleId: ");
        int articleId = scanner.nextInt();
        if(!isArticleIdExists(articleId))
        {
        	System.out.println("Invalid ID Try Again!!");
        }
        System.out.print("Enter magazineId: ");
        int magazineId=scanner.nextInt();
		System.out.print("Enter title: ");
        String magazineTitle = scanner.next();
        System.out.print("Enter author: ");
        String author = scanner.next();
        System.out.print("Enter content: ");
        String content=scanner.next();
        System.out.print("Enter publish date (yyyy-mm-dd) manner: ");
        String publiDate=scanner.next();
        Date publishDate =convertDate(publiDate);
        
        
        Article article = new Article();
        article.setArticleId(articleId);
        article.setMagazineId(magazineId);
        article.setTitle(magazineTitle);
        article.setAuthor(author);
        article.setContent(content);
        article.setPublishDate(publishDate);
        
        ArticleService.updateArticle(article);
        	
	}
	
	
	 public static boolean isArticleIdExists(int articleId) {
	        String sql = "SELECT 1 FROM Article WHERE article_id = ?";
	        try (Connection conn = DbConnection.getConnection();
	             PreparedStatement stmt = conn.prepareStatement(sql)) {
	            stmt.setInt(1, articleId);
	            try (ResultSet rs = stmt.executeQuery()) {
	                return rs.next(); 
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return false;
	    }
	

	private static void deleteArticle() {
		
		System.out.print("Enter articleId: ");
		int article_Id=scanner.nextInt();
		ArticleService.deleteArticle(article_Id);
		
	}


	
	
private static void displaySubscriptionMenu() {
        while (true) {
            System.out.println("\nSubscription Management:");
            System.out.println("1. Subscribe to a Magazine");
            System.out.println("2. View All Subscriptions");
            System.out.println("3. Update Subscription");
            System.out.println("4. Cancel Subscription");
            System.out.println("5. Back to Main Menu");

            int choice = getIntInput();

            switch (choice) {
                case 1:
                    subscribe();
                    break;
                case 2:
                    viewAllSubscriptions();
                    break;
                case 3:
                    updateSubscription();
                    break;
                case 4:
                    cancelSubscription();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
   

private static void subscribe() {
	
	System.out.print("Enter userId: ");
	int userId=scanner.nextInt();
	System.out.print("Enter magazineId: ");
	int magazineId=scanner.nextInt();
	
    Date subsDate=SubscriptionService.todayDate();
    System.out.println("Subscription Date: "+subsDate);
    Date expDate=SubscriptionService.expDate();
    System.out.println("ExpiryDate: "+expDate);
    
    String status="active";
    //status=SubscriptionService.status();
    Subscription subscribe=new Subscription();
    subscribe.setUserId(userId);
    subscribe.setMagazineId(magazineId);
    subscribe.setSubscriptionDate(expDate);
    subscribe.setExpiryDate(expDate);
    subscribe.setStatus(status);
    SubscriptionService.subscribe(subscribe);
	
}


private static void viewAllSubscriptions() {
	
	SubscriptionService.viewAllSubscriptions();
	
}


private static void updateSubscription() {
	
	System.out.print("Enter subscriptionId: ");
	int subscriptionId=scanner.nextInt();
	System.out.print("Enter userId: ");
    int userId = scanner.nextInt();
    System.out.print("Enter magazineId: ");
    int magazineId=scanner.nextInt();
    Date subscribeDate =SubscriptionService.todayDate();
    Date expiryDate =SubscriptionService.expDate();
    String status="active";
    
    Subscription subscribe=new Subscription();
    subscribe.setSubscriptionId(subscriptionId);
    subscribe.setUserId(userId);
    subscribe.setMagazineId(magazineId);
    subscribe.setSubscriptionDate(subscribeDate);
    subscribe.setExpiryDate(expiryDate);
    subscribe.setStatus(status);
    SubscriptionService.subscribe(subscribe);
}


public static boolean isSubscriptionIdExists(int subscriptionId) {
    String sql = "SELECT 1 FROM Subscription WHERE subscription_id = ?";
    try (Connection conn = DbConnection.getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setInt(1, subscriptionId);
        try (ResultSet rs = stmt.executeQuery()) {
            return rs.next(); 
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return false;
}



private static void cancelSubscription() {
	
	System.out.print("Enter subscription id: ");
	int subscriptionId=scanner.nextInt();
	SubscriptionService.cancelSubscription(subscriptionId);
	
}


	private static int getIntInput() {
        while (!scanner.hasNextInt()) {
            System.out.println("Invalid input. Please enter a number.");
            scanner.next();
        }
        return scanner.nextInt();
    }
}

